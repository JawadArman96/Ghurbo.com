<?php

/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
exec('C:/wamp64/bin/php/php5.6.35/php.exe C:/wamp64/www/ghurbo/test.php one_way_all_search DAC CGP 2018-08-18 2018-09-26 economy 1 0 0',$output);
#$str='C:/wamp64/bin/php/php5.6.35/php.exe C:/wamp64/www/ghurbo/Test.php '.$argv[1].' '.$argv[2].' '.$argv[3].' '.$argv[4].' '.$argv[5].' '.$argv[6].' '.$argv[7].' '.$argv[8].' '.$argv[9];
#exec($str,$output);
#file_put_contents('C:\Users\User1\Desktop\nlp\New folder\ghurbo_bot\venv\description.txt', $output);        
#exec('C:/wamp64/bin/php/php5.6.35/php.exe C:/wamp64/www/ghurbo/test.php',$output);

file_put_contents('C:\wamp64\www\ghurbo\out.txt', $output);        


?>

