

<?php
$stdout = fopen('php://stdout', 'w');


$flightType =$argv[1];#'one_way_all_search'; #$_POST['flight_type'];
$departCity =$argv[2];# 'DAC';#$_POST['depart_city'];
$arriveCity =$argv[3];# 'CGP';#$_POST['arrive_city'];
$departDate =$argv[4];# '2018-08-18';#$_POST['depart_date'];
$returnDate =$argv[5];# '2018-09-26';#$_POST['return_date'];
$class =$argv[6];# 'economy';#$_POST['class'];
$adultCount = $argv[7];#$_POST['adult'];
$childCount = $argv[8];#$_POST['child'];
$infantCount =$argv[9]; #$_POST['infant'];

$url = "http://dev.ghurbo.com/api/flight_search";

if($flightType == 'one_way_all_search')
	$postFields = "secret_key=123456&search_type=".$flightType."&depart_city=".$departCity."&arrive_city=".$arriveCity."&depart_date=".$departDate."&adult_count=".$adultCount."&child_count=".$childCount."&infant_count=".$infantCount."&seat_type_class=".$class;

elseif ($flightType == 'round_trip_all_search')
	$postFields = "secret_key=123456&search_type=".$flightType."&depart_city=".$departCity."&arrive_city=".$arriveCity."&depart_date=".$departDate."&return_date=".$returnDate."&adult_count=".$adultCount."&child_count=".$childCount."&infant_count=".$infantCount."&seat_type_class=".$class;

$ch = curl_init($url);
curl_setopt($ch, CURLOPT_POST, true);
curl_setopt($ch, CURLOPT_POSTFIELDS, $postFields);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
$result = curl_exec($ch);

$result = json_decode($result);

if($flightType == 'one_way_all_search') {
	$nonStopFlights = $result->data->nostop;
		if(sizeof($nonStopFlights) == 0)
			echo " N/A <br />" ;
		else {
			for($i=0; $i < sizeof($nonStopFlights); $i++) { 
				$arrival = $nonStopFlights[$i]->arrival;
				echo  $arrival->airlinesName . " " . $arrival->flightName . " " . $arrival->flightNo ."<br/>";

				echo  $arrival->departureDate . " " . $arrival->departureTime ."<br/>";
				echo  $arrival->departureCity . " " .$arrival->departAirport . " (".$arrival->departFrom.")" . "<br/>";

				echo  $arrival->arrivalDate . " " . $arrival->arrivalTime . "<br/>";
				echo  $arrival->arrivalCity . " " .$arrival->arriveAirport . " (".$arrival->arriveTo.")" . "<br/>";


				echo  $arrival->flightPriceCurrency . " " . $arrival->flightPrice . "<br/>";
			}
			echo "<br/>";	
		}

		echo "<br />";	

		$multiStopFlights = $result->data->multistop;
		echo "<h3> Multi-stop Flights: </h3>";
		for($i=0; $i < sizeof($multiStopFlights); $i++) {
			echo "<h3> Route#" . ($i+1) . ": </h3>";
			echo "<p> <i>" . $multiStopFlights[$i]->arrival[0]->flightPriceCurrency . " " . $multiStopFlights[$i]->arrival[0]->flightPrice . "</i> </p>";
			echo "<table> <tr> <th> Flight No. </th> <th> Departure </th> <th> Arrival </th> </tr>";
			for($j=0; $j < sizeof($multiStopFlights[$i]->arrival); $j++) {
				$arrival = $multiStopFlights[$i]->arrival[$j];

				echo $arrival->airlinesName . " " . $arrival->flightName . " " . $arrival->flightNo . "<br/>";

				echo  $arrival->departureDate . " " . $arrival->departureTime . "<br/>";
				echo  $arrival->departureCity . " " .$arrival->departAirport . " (".$arrival->departFrom.")" . "<br/>";

				echo  $arrival->arrivalDate . " " . $arrival->arrivalTime . "<br/>";
				echo  $arrival->arrivalCity . "" .$arrival->arriveAirport . " (".$arrival->arriveTo.")" . "<br/>";

			}
			echo "<br/>";
			echo "<br/>";
		}
	}

	if($flightType == 'round_trip_all_search') {
		$nonStopFlights = $result->data->nostop;
		echo "<h3> Non-stop Flights: </h3>"; 
		if(sizeof($nonStopFlights) == 0)
			echo " N/A <br />";
		else {
			echo "
			<table>
				<tr>
					<th> Outbound Flight </th>
					<th> Return Flight </th>
					<th> Total Fare </th>
				</tr>";
				for($i=0; $i < sizeof($nonStopFlights); $i++) {
					$arrival = $nonStopFlights[$i]->arrival;
					$return = $nonStopFlights[$i]->return;
					
					echo $arrival->airlinesName . " " . $arrival->flightName . " " . $arrival->flightNo . "<br/>";

					echo $arrival->departFrom . " " . $arrival->departureDate . "  " . $arrival->departureTime . " " . $arrival->arriveTo . " " . $arrival->arrivalDate . " " . $arrival->arrivalTime . "<br/>";

					echo $arrival->departureCity." ".$arrival->departAirport;
					echo "<br />";
					echo $arrival->arrivalCity.", ".$arrival->arriveAirport . "<br/>";


					echo $return->airlinesIcon . "<br/>" . $return->airlinesName . " " . $return->flightName . " " . $return->flightNo . "<br/>";

					echo $return->departFrom . " " . $return->departureDate . " - " . $return->departureTime . " "  . $return->arriveTo . " " . $return->arrivalDate . " - " . $return->arrivalTime . "<br/>";

					echo  $return->departureCity." ".$return->departAirport;
					echo " (".$return->departFrom.")";
					echo "<br />";
					echo $return->arrivalCity.", ".$return->arriveAirport . "<br/>";

					echo $arrival->flightPriceCurrency . " " .$arrival->flightPrice . "<br/>";
				}
				echo "<br/>";
			}
			echo "<br />";

			$multiStopFlights = $result->data->multistop;
			echo "<h3> Multi-stop Flights: </h3>"; 
			echo "<table> <tr> <th> Outbound Flight(s) </th> <th> Return Flight(s) </th> <th> Total Fare </th> </tr>";
			for($i=0; $i < sizeof($multiStopFlights); $i++) {			
				echo "<td>";	
				for($j=0; $j < sizeof($multiStopFlights[$i]->arrival); $j++) {
					$arrival = $multiStopFlights[$i]->arrival[$j];
					if ($j==0)
						echo $arrival->airlinesIcon . '<br/>';

					echo   $arrival->airlinesName . " " . $arrival->flightName . " " . $arrival->flightNo . "<br/>";

					echo  $arrival->departFrom . " " . $arrival->departureDate . " - " . $arrival->departureTime . " " . $arrival->arriveTo . " " . $arrival->arrivalDate . " - " . $arrival->arrivalTime . "<br/>";
					echo $arrival->departureCity . " - " . $arrival->arrivalCity . "<br/>";
				}

				echo "<br/>";
				for($k=0; $k < sizeof($multiStopFlights[$i]->return); $k++) {
					if ($k==0)
						#echo . $return->airlinesIcon . '"> <br>';

					echo $return->airlinesName . " " . $return->flightName . " " . $return->flightNo . "<br/>";

					echo  $return->departFrom . " " . $return->departureDate . " - " . $return->departureTime . $return->arriveTo . " " . $return->arrivalDate . " - " . $return->arrivalTime . "<br/>";
					echo $return->departureCity . " - " . $return->arrivalCity . "<br/>";
				}
				echo $multiStopFlights[$i]->arrival[0]->flightPriceCurrency . " " . $multiStopFlights[$i]->arrival[0]->flightPrice . "<br/>";
				echo "<br/>";
			}
		}
		?>
