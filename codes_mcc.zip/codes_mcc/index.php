
<?php

/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
exec('C:/wamp64/bin/php/php5.6.35/php.exe C:/wamp64/www/ghurbo/Test.php one_way_all_search DAC CGP 2018-08-18 2018-09-26 economy 1 0 0',$output);
#$str='C:/wamp64/bin/php/php5.6.35/php.exe C:/wamp64/www/ghurbo/Test.php '.$argv[1].' '.$argv[2].' '.$argv[3].' '.$argv[4].' '.$argv[5].' '.$argv[6].' '.$argv[7].' '.$argv[8].' '.$argv[9];
#exec($str,$output);
file_put_contents('out.txt', $output);        



?>



<!--<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width,initial-scale=1,user-scalable=0">
  <title>Ghurbo Flight Search</title>
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
  <link rel="stylesheet" href="//res.wx.qq.com/open/libs/weui/1.1.2/weui.min.css"/>

  <style>
    .fb{
      background-color:#4080FF;
    }

    body{
      background: #efefef;
      padding: 20px;
    }

    .weui-cells__title {
      padding-left: 0px;
      padding-right: 0px;
    }
  </style>

</head>
<body>
  <div class="weui-cells__title">Ghurbo Flight Search</div>
  <form id="dropreqform" action="results.php" method="post">
   <input type="radio" value="round_trip_all_search" name="flight_type" checked="checked" id="radio1" onclick="display()"></input>
   <label for="radio1">Round trip</label>
   &nbsp; &nbsp; &nbsp; 
   <input type="radio" value="one_way_all_search" name="flight_type" id="radio2" onclick="hide()"></input>
   <label for="radio2">One way</label>
   <input type="hidden" name="fbid" value="">
   <input type="hidden" name="product_subcategory_id" value="0">

   <div class="weui-cells__title"></div>
   <select required name="depart_city" id="select1" class="custom-select">
    <option value="0" disabled="disabled" selected="selected" id="place">Flying to</option>
    <option value="DAC">Dhaka,Bangladesh-Dhaka / Hazrat Shahjalal International Airport(DAC)</option>
    <option value="SIN">Singapore,Singapore-Singapore Changi Airport(SIN)</option>
    <option value="LHR">London, United Kingdom-London Heathrow Airport(LHR)</option>
    <option value="YVR">Vancouver,Canada-Vancouver International Airport(YVR)</option>
    <option value="JFK">New York,United States-John F Kennedy International Airport(JFK)</option>
    <option value="CDG">Paris,France-Charles de Gaulle Internatioanl Airport(CDG)</option>
    <option value="CCU">Kolkata,India-Netaji Subhassh Chandra Bose International Airport(CCU)</option>
  </select>

  <select required name="arrive_city" id="select1" class="custom-select">
    <option value="0" disabled="disabled" selected="selected" id="place">Flying to</option>
    <option value="DAC">Dhaka,Bangladesh-Dhaka / Hazrat Shahjalal International Airport(DAC)</option>
    <option value="SIN">Singapore,Singapore-Singapore Changi Airport(SIN)</option>
    <option value="LHR">London, United Kingdom-London Heathrow Airport(LHR)</option>
    <option value="YVR">Vancouver,Canada-Vancouver International Airport(YVR)</option>
    <option value="JFK">New York,United States-John F Kennedy International Airport(JFK)</option>
    <option value="CDG">Paris,France-Charles de Gaulle Internatioanl Airport(CDG)</option>
    <option value="CCU">Kolkata,India-Netaji Subhassh Chandra Bose International Airport(CCU)</option>
  </select>
</div>

<div class="weui-cells__title">Depart date:
  <input name="depart_date" type="date"> 
</div>

<div id="ret" class="weui-cells__title">
  Return date:<input name="return_date" type="date">
</div>


<div class="weui-cells__title">Class
  <select name="class">
    <option value="economy">Economy</option>
    <option value="economy_standard">Economy Standard</option>
    <option value="economy_premium">Economy Premium</option>
    <option value="business">Business Class</option>
  </select> 
</div>

<div class="weui-cells__title">
  Adult
  <select name="adult" id="adult" onchange="changeOptAdult();">
    <option>1</option>
    <option>2</option>
    <option>3</option>
    <option>4</option>
    <option>5</option>
    <option>6</option>
    <option>7</option>
    <option>8</option>
    <option>9</option>
  </select>
  Child
  <select name="child" id="child" onchange="changeOptChild();">
   <option>0</option> 
   <option>1</option>
   <option>2</option>
   <option>3</option>
   <option>4</option>
   <option>5</option>
   <option>6</option>
   <option>7</option>
   <option>8</option>
 </select>
 Infant
 <select name="infant" id="infant" onchange="changeOptInfant();">
   <option>0</option> 
   <option>1</option>
 </select>

 <p id="passenger_count"> 1 passenger </p>
</div>


<div class="weui-btn-area">
  <button type="submit" form="dropreqform" class="weui-btn fb">Submit</button>
</div>
</form>

<script>
  function hide() {
    var x = document.getElementById("ret");
    x.style.display = "none"
  }

  function display() {
    var x = document.getElementById("ret");
    x.style.display = "inline"
  }

  function changeOptAdult() {
    var adultCount = $("#adult").val();
    var childCount = $("#child").val();
    var infantCount = $("#infant").val();

    if(adultCount < infantCount)
      var x = 1;

    $("#infant").empty();
    for(var i=0; i <= adultCount; i++) {
      $("#infant").append('<option>' + i + '</option>');
    }
    $("#child").empty();
    for(var i=0; i <= (9 - adultCount); i++) {
      $("#child").append('<option>' + i + '</option>');
    }
    $("#child").val(childCount);

    if(x) {
      $("#infant").val(0);
    }
    else {
      $("#infant").val(infantCount);
    }

    var total = parseInt($("#child").val()) + parseInt($("#adult").val()) + parseInt($("#infant").val());
    $("#passenger_count").text(total + " passengers");
  }

  function changeOptChild() {
    var childCount = $("#child").val();
    var adultCount = $("#adult").val();
    var infantCount = $("#infant").val();

    $("#adult").empty();
    for(var i=0; i <= (9-childCount); i++) {
      $("#adult").append('<option>' + i + '</option');
    }
    $("#adult").val(adultCount);
    $("#infant").val(infantCount);

    var total = parseInt($("#child").val()) + parseInt($("#adult").val()) + parseInt($("#infant").val());
    $("#passenger_count").text(total + " passengers");
  }

  function changeOptInfant() {
    var total = parseInt($("#child").val()) + parseInt($("#adult").val()) + parseInt($("#infant").val());
    if(total == 1)
      $("#passenger_count").text(total + " passenger"); 

    else 
     $("#passenger_count").text(total + " passengers");
 }
</script>
</body>
</html>-->
